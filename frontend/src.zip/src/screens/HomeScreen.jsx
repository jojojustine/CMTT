// frontend/src/screens/HomeScreen.jsx - keep it simple
import Hero from "../components/Hero";

const HomeScreen = () => {
  return <Hero />;
}

export default HomeScreen;