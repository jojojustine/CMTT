// Create file: frontend/src/screens/TasksScreen.jsx
import { useState } from 'react';
import TaskForm from '../components/TaskForm';
import TaskList from '../components/TaskList';
import { useSelector } from 'react-redux';

const TasksScreen = () => {
  const { userInfo } = useSelector((state) => state.auth);
  const [tasks, setTasks] = useState([]);
  
  const addTask = (newTask) => {
    setTasks([...tasks, newTask]);
  };
  
  const toggleComplete = (taskId) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? {...task, completed: !task.completed} : task
    ));
  };
  
  const deleteTask = (taskId) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };
  
  return (
    <div>
      <h1>Welcome, {userInfo.name}</h1>
      <p>Manage your tasks below:</p>
      <TaskForm onAddTask={addTask} />
      <TaskList 
        tasks={tasks} 
        onToggleComplete={toggleComplete}
        onDeleteTask={deleteTask}
      />
    </div>
  );
};

export default TasksScreen;